-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2024 at 02:23 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal_berita`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(10) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama_kategori`, `created_at`, `updated_at`) VALUES
(2, 'Kesehatan', '2024-08-30 21:21:38', '2024-08-30 21:21:38'),
(3, 'Politik', '2024-08-30 21:21:44', '2024-08-30 21:21:44'),
(4, 'Hiburan', '2024-08-30 21:21:50', '2024-08-30 21:21:50'),
(5, 'Olahraga', '2024-08-30 21:22:53', '2024-08-30 21:22:53');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `id_kategori` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `image`, `content`, `id_kategori`, `created_at`, `updated_at`) VALUES
(2, 'CHRIS PUTRA JUARA 2 MR. OLYMPIA', 'assets/chrisputra.jpg', 'JAKARTA - Chris Putra, atlet binaraga Indonesia yang juga dikenal sebagai fitness influencer berhasil mencetak sejarah dengan memenangkan peringkat pertama di kejuaraan binaraga DMS Pro Show di China yang berlangsung pada 23 Juni 2024.\r\n\r\nKeberhasilan ini diraih Chris Putra setelah sebelumnya mengalami tiga kali kegagalan dalam kompetisi serupa, yaitu Olympia Qualifier.\r\n\r\nKemenangan ini tidak hanya membawa kebanggaan bagi Indonesia, tetapi juga membuka jalan bagi Chris untuk berlaga di Mr Olympia, kejuaraan binaraga paling bergengsi di dunia yang akan diadakan di Las Vegas tahun ini.', 5, '2024-08-30 21:23:26', '2024-08-30 21:23:26'),
(3, 'SIDANG MK ', 'assets/berita2.jpg', 'Mahkamah Konstitusi (MK) telah membacakan putusan terhadap permohonan uji materi Undang-Undang Pilkada. Setidaknya, ada lima putusan terkait dengan Pilkada yang diputus MK.\r\nSidang pembacaan putusan perkara-perkara itu digelar MK di Gedung MK, Selasa (20/8/2024). Berikut putusan-putusan MK terkait Pilkada:\r\n\r\nBaca artikel detiknews, \"5 Putusan MK: Parpol Tanpa Kursi Bisa Usung Calon hingga Syarat Usia\" selengkapnya https://news.detik.com/berita/d-7500329/5-putusan-mk-parpol-tanpa-kursi-bisa-usung-calon-hingga-syarat-usia.\r\n\r\nDownload Apps Detikcom Sekarang https://apps.detik.com/detik/', 3, '2024-08-30 21:24:06', '2024-08-30 21:24:06'),
(4, 'COVID 19 DESEMBER 2020', 'assets/5fedd0b455cb7093049541.jpeg', 'Jakarta (ANTARA) - Tahun 2020 menjadi tahun yang menantang bagi Indonesia sejak pandemi virus corona melanda pada Maret lalu.\r\n\r\nSepanjang 2020, kementerian, termasuk Kementerian Komunikasi dan Informatika, mengeluarkan sejumlah program untuk membantu masyarakat mengatasi pandemi COVID-19.\r\n\r\nSepanjang tahun ini, Kominfo tetap melanjutkan program utama mereka, seperti membangun infrastruktur telekomunikasi dan menambah agenda baru, agar masyarakat dan pelaku usaha bisa beradaptasi dengan kebiasaan-kebiasaan baru yang muncul akibat pandemi virus corona.\r\n\r\nAkhir Maret, tidak lama setelah virus corona terdeteksi berada di Indonesia, Kominfo meluncurkan aplikasi pelacak persebaran virus corona bernama PeduliLindungi, yang dikembangkan kementerian bersama operator seluler.', 2, '2024-08-30 21:25:14', '2024-08-30 21:25:14'),
(5, 'GEDUNG BARU IKN', 'assets/66c46a93d9626.jpeg', 'Pemerintah terus menggeber pembangunan Ibu Kota Nusantara (IKN) di Kalimantan Timur. Saat ini progres pembangunan IKN tahap 1 telah mencapai 92%.\r\nInformasi ini disampaikan oleh Ketua Satgas Pelaksanaan Pembangunan Infrastruktur IKN Kementerian PUPR Danis H Sumadilaga. Sedangkan untuk batch 2 saat ini progresnya mencapai 57%.\r\n\r\n\"Untuk basic infrastructure yang batch 1 92% lebih. Yang batch 2 udah 57%. Yang batch 3 udah hampir 20%,\" kata Danis di Kementerian PUPR, Jakarta Selatan, Jumat (30/9/2024).\r\n\r\nBaca artikel detikfinance, \"Progres Pembangunan IKN Tahap 1 Sudah 92%\" selengkapnya https://finance.detik.com/infrastruktur/d-7517446/progres-pembangunan-ikn-tahap-1-sudah-92.\r\n\r\nDownload Apps Detikcom Sekarang https://apps.detik.com/detik/', 3, '2024-08-30 21:25:39', '2024-08-30 21:25:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(100) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `profile_image`, `role`) VALUES
(1, 'user', '$2y$10$0jA1T4/OGMMtXzfA2GKN6O5RaUzgNMWNHpoWQ/1fD/ucHvvYj7z2y', 'assets/WhatsApp Image 2024-06-24 at 19.46.25.jpeg', 'user'),
(7, 'admin', '$2y$10$5haeAG2xXcCsqKoDUPff.OlQCV/jcDjfR79XZAEFF9gSg7bg80K9m', 'assets/WhatsApp Image 2024-06-24 at 19.46.25.jpeg', 'admin'),
(8, 'adi ', '$2y$10$.GUzE/IWXyKdJlphUASo.uQace0WVyGYTRMHbZ7zB0pq6PCSWEeIa', '', 'user'),
(9, 'rafif', '$2y$10$YokJWPblY21f/eNGC9ZaJ.cXCg9dj63EtTWrwRKzZIQOfdQ/FGBu.', '', 'user'),
(10, 'bagus', '$2y$10$C4g5v7PgdBzmlQXu7PMp/eBvr9qlNdlOxRjmJF0bqGIEjwx5Q7CWe', '', 'user'),
(12, 'diki', '$2y$10$NaonvWNUp8goKA5rlqZXHeNSIf9vljHOlqnGv.X9U.1s68/aptVb2', '', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kategori` (`id_kategori`) USING BTREE,
  ADD KEY `id_kategori_2` (`id_kategori`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `fk_kategori` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
